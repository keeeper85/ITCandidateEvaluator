If you change the files in these directory, you may not be able to load recruitments in the app.
However, feel free to backup these files in a save place.