You can easily create here new file with presets.
To make it work, its name should contain 'presets'.
The file extension must be '.json' and it must be a proper JSON file to avoid exceptions.
The file should contain the following:
{"Resume and social media evaluation":X,"Own projects":X,"English language assessment":X,"Live coding":X,"Salary expectations":X,"Technical questions":X,"Soft skills":X,"Previous work experience":X}
- change X to desired value (0-10)
- order of steps doesn't matter
- if you don't place any of the stages - their values will be set to '0' and won't occur during the evaluation