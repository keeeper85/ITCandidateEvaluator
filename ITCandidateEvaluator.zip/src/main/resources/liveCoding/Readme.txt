You can create new files with tasks or change the existing files.
There are only 2 conditions:

- each file must contain the word: 'task' and '.txt' extension
- one file = one task, don't make it too long to avoid problems with presentation

Use html tags (see the given examples) for formatting.
If you want to keep default formatting use <pre></pre> - it helps at presenting code samples.