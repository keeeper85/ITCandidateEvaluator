You can create new files with questions or add questions to the existing files.
There are only 2 conditions:

- each file must contain the word: 'questions' and '.txt' extension
- questions can be multiple line long but must be separated with one empty line (one from another)